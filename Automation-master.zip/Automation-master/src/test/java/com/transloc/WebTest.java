package com.transloc;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class WebTest {
    private WebDriver driver;

    /**
     * Change the prop if you are on Windows or Linux to the corresponding file type
     * The chrome WebDrivers are included on the root of this project, to get the
     * latest versions go to https://sites.google.com/a/chromium.org/chromedriver/downloads
     */
    @Before
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        Capabilities capabilities = DesiredCapabilities.chrome();
        driver = new ChromeDriver(capabilities);
        driver.navigate().to("https://login.stage.transloc.com/login/?next=https://architect.stage.transloc.com/");
        WebElement name = driver.findElement(By.id("username"));
        name.sendKeys("qa_user_1");
        WebElement password = driver.findElement(By.id("password"));
        password.sendKeys("BhZVJdz6$C!r");
        WebElement login = driver.findElement(By.cssSelector("input[type='submit']"));
        login.click();
    }

    @Test
    public void test_validate_title_is_present() {
        new HomePage(driver)
                .validateTitleIsPresent();
    }
    @Test
    public void test_validate_logout() {
        new HomePage(driver)
                .logout();
    }
    @Test
    public void validateCreateNewFeed() {
        new HomePage(driver)
                .validateCreateNewFeed();
    }


    @After
    public void teardown() {
        driver.quit();
        System.clearProperty("webdriver.chrome.driver");
    }
}
