package com.transloc;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.IntStream;

/**
 * Created on 5/23/17.
 */
public class HomePage extends BasePage {


    public HomePage(WebDriver driver) {
        super(driver);
    }

    public void validateTitleIsPresent() {
        sleep(6000);
        WebElement title = driver.findElement(By.cssSelector("[data-id='user-nav-profile']"));
        Assert.assertTrue(title.isDisplayed());
    }


    public void validateCreateNewFeed() {
          String name =createFeed();
         String title = driver.findElement(By.cssSelector("[title='"+name+"']")).getText();
         Assert.assertTrue(title.equals(name));
    }
    public void logout(){
        validateCreateNewFeed();
        WebElement newButton = driver.findElement(By.cssSelector("[data-id='user-nav-logout']"));
        newButton.click();
        WebElement loginPage = driver.findElement(By.className("login-container"));
        Assert.assertTrue(loginPage.isDisplayed());
    }
    public String createFeed(){

        Random rand = new Random();
        int rand_int1 = rand.nextInt(1000);
        String feedName ="QA "+ rand_int1;

        sleep(6000);
        WebElement newButton = driver.findElement(By.cssSelector("[data-id='new-button']"));
        newButton.click();
        sleep(2000);
        WebElement feedTab = driver.findElement(By.cssSelector("[data-id='feed-info-tab']"));
        feedTab.click();
        WebElement name = driver.findElement(By.cssSelector("[data-id='field-name']"));
        name.sendKeys(feedName);
        WebElement publisher = driver.findElement(By.cssSelector("[data-id='field-publisher_name']"));
        publisher.sendKeys("QA");
        WebElement url = driver.findElement(By.cssSelector("[data-id='field-publisher_url']"));
        url.sendKeys("www.yahoo.com");
        WebElement language = driver.findElement(By.cssSelector("[data-id='field-language']"));
        language.sendKeys("English");
        WebElement agencyTab = driver.findElement(By.cssSelector("[data-id='agency-info-tab']"));
        agencyTab.click();
        sleep(2000);
        WebElement agencyURL = driver.findElement(By.cssSelector("[data-id='field-gtfs_agency_url']"));
        agencyURL.sendKeys("www.yahoo.com");
        WebElement saveButton = driver.findElement(By.cssSelector("[data-id='save-button']"));
        saveButton.click();sleep(2000);
        return feedName;
    }
}
